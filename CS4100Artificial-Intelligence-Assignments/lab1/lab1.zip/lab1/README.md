# Homework 0

This homework is intended to give you some practice on basic Python concepts and an introduction to Numpy, an important Python package for this class.

A few instructions to set up:

1. Ensure Python 3 is installed on your computer. If not, follow the instructions at https://realpython.com/installing-python/ for your respective operating system.
2. In a terminal, run the command 'pip install numpy'
2. In a terminal, run the command 'pip install jupyter'
3. To start the jupyter notebook server, run the command 'jupyter notebook Intro2Python.ipynb'

